import React, { useState } from 'react';

interface StudentQuizProps {
  onBackToPath: () => void;
}

export const StudentQuiz: React.FC<StudentQuizProps> = ({ onBackToPath }) => {
  const [selectedOption, setSelectedOption] = useState<string>('b'); // Default to Option B as in image
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [showTutor, setShowTutor] = useState<boolean>(false);
  const [loadingAI, setLoadingAI] = useState<boolean>(false);
  const [customPrompt, setCustomPrompt] = useState<string>('');

  const [tutorData, setTutorData] = useState<{
    feedback: string;
    reference: string;
    formula: string;
    explanation: string;
  }>({
    feedback: "Not quite! You selected Option B. Bạn đang nhầm lẫn một chút về công thức tính động năng.",
    reference: "Slide 12 - Energy",
    formula: "KE = 1/2 * m * v²",
    explanation: "Because velocity (v) is squared, doubling it (2v)² results in a factor of 4. Therefore, it quadruples.",
  });

  const question = "In classical mechanics, how does the kinetic energy of an object change if its velocity is doubled?";

  const options = [
    { id: 'a', label: 'Option A', text: 'It remains the same.' },
    { id: 'b', label: 'Option B', text: 'It doubles.' },
    { id: 'c', label: 'Option C', text: 'It quadruples.' },
    { id: 'd', label: 'Option D', text: 'It halves.' },
  ];

  const handleSubmit = async () => {
    setSubmitted(true);
    setShowTutor(true);

    if (selectedOption === 'c') {
      setTutorData({
        feedback: "Chính xác! Excellent work!",
        reference: "Slide 12 - Energy",
        formula: "KE = 1/2 * m * v²",
        explanation: "Because velocity is squared, doubling it increases kinetic energy by 2² = 4 times!",
      });
    } else {
      // Trigger AI tutor call if needed
      try {
        const res = await fetch('/api/ai-tutor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question,
            selectedOption,
            correctAnswer: 'c',
            topic: 'Physics - Kinetic Energy',
          }),
        });
        const data = await res.json();
        if (data.feedback) {
          setTutorData(data);
        }
      } catch {
        // keep default tutorData
      }
    }
  };

  const handleAskTutor = async (promptText: string) => {
    setLoadingAI(true);
    try {
      const res = await fetch('/api/ai-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question,
          selectedOption,
          correctAnswer: 'c',
          userPrompt: promptText,
          topic: 'Physics - Kinetic Energy',
        }),
      });
      const data = await res.json();
      setTutorData(data);
    } catch {
      // fallback
    } finally {
      setLoadingAI(false);
      setCustomPrompt('');
    }
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] min-h-screen font-body-md overflow-x-hidden pb-32">
      <main className="max-w-3xl mx-auto pt-8 px-4 md:px-10 relative">
        {/* Header & Progress */}
        <header className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBackToPath}
              className="flex items-center text-[#454652] hover:text-[#0f2a90] transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined mr-2">arrow_back</span>
              <span className="font-label-caps text-xs">Back to Module</span>
            </button>
            <div className="font-label-caps text-xs text-[#0f2a90] bg-[#2e44a7]/10 px-3.5 py-1 rounded-full font-semibold">
              Question 4 of 10
            </div>
          </div>

          {/* Momentum Bar */}
          <div className="w-full h-3 bg-[#e5eeff] rounded-full overflow-hidden relative shadow-inner">
            <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#0f2a90] to-[#006c49] rounded-full w-2/5 transition-all duration-500 ease-out" />
          </div>
        </header>

        {/* Quiz Canvas */}
        <section className="bg-white rounded-2xl shadow-[0_4px_12px_rgba(0,0,0,0.03)] p-6 md:p-10 border border-[#c5c5d4]/40 mb-8">
          <h1 className="font-headline-md text-2xl font-semibold text-[#0b1c30] mb-8 leading-snug">
            {question}
          </h1>

          <div className="space-y-4">
            {options.map((opt) => {
              const isSelected = selectedOption === opt.id;
              const isWrong = submitted && isSelected && opt.id !== 'c';
              const isCorrect = submitted && opt.id === 'c';

              let borderStyle = "border-[#c5c5d4]/50 hover:border-[#0f2a90]/50 hover:bg-[#eff4ff]";
              if (isSelected) borderStyle = "border-[#0f2a90] bg-[#eff4ff]";
              if (isWrong) borderStyle = "border-[#ba1a1a] bg-[#ffdad6]/20";
              if (isCorrect) borderStyle = "border-[#006c49] bg-[#6cf8bb]/20";

              return (
                <label
                  key={opt.id}
                  onClick={() => !submitted && setSelectedOption(opt.id)}
                  className={`flex items-start p-4 md:p-5 border-2 rounded-xl cursor-pointer transition-all duration-200 group ${borderStyle}`}
                >
                  <div className="flex-shrink-0 w-6 h-6 rounded-full border-2 border-[#c5c5d4] group-hover:border-[#0f2a90] flex items-center justify-center mr-4 mt-0.5 transition-colors">
                    <div
                      className={`w-3 h-3 rounded-full transition-transform duration-200 ${
                        isSelected ? 'bg-[#0f2a90] scale-100' : 'bg-transparent scale-0'
                      }`}
                    />
                  </div>
                  <div>
                    <span className="block font-label-caps text-xs text-[#454652] mb-1">{opt.label}</span>
                    <span className="block font-body-lg text-lg text-[#0b1c30]">{opt.text}</span>
                  </div>
                </label>
              );
            })}
          </div>

          <div className="pt-8 flex justify-end">
            <button
              onClick={handleSubmit}
              className="bg-[#006c49] text-white px-8 py-3 rounded-full font-label-caps text-xs border-b-2 border-[#6ffbbe] shadow-md hover:bg-[#006c49]/90 transition-all active:scale-95 flex items-center gap-2 pulse-effect cursor-pointer"
            >
              Submit Answer
              <span className="material-symbols-outlined text-sm">send</span>
            </button>
          </div>
        </section>

        {/* AI Tutor Overlay Panel */}
        {showTutor && (
          <div className="fixed md:absolute bottom-0 md:bottom-auto md:top-24 left-0 w-full md:w-[420px] md:-right-12 md:left-auto z-50 p-4 md:p-0">
            <div className="bg-white rounded-2xl shadow-[0_12px_24px_rgba(46,68,167,0.15)] border border-[#2e44a7]/20 overflow-hidden flex flex-col max-h-[80vh] md:max-h-[600px]">
              {/* Tutor Header */}
              <div className="bg-[#2e44a7] p-4 flex items-center justify-between text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center overflow-hidden border-2 border-[#b9c3ff]">
                    <img
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuAILKyEMY1ZDc7bcD3cBvIgmnkjglQ2RxU7agZuHbSZOlg7Y0d2ZT8VQ47H2FptepMs3ipq8MCHmaMaHsneuMgoqYKaeH8-JP6W40qD5FPKo2TEdl3d8LGkcbSr2_QAiWgO_4SX_FmAMHoEwCAtN5pPJ5MJlkHsjjbYmHFGdEiytoBDQ1C6QA5BXm-jqvlHb9i4_o5pjKTW0rxqB8PVzu26V33DM8Euld5pesvEDd8-_YbahVucsHIDfQ"
                      alt="AI Tutor Avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-headline-md text-base leading-tight font-semibold">VLearn AI Guide</h3>
                    <p className="font-label-caps text-[10px] text-[#b9c3ff]">Always learning</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowTutor(false)}
                  className="text-white hover:bg-white/10 p-2 rounded-full transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              {/* Tutor Content */}
              <div className="p-5 flex-grow overflow-y-auto bg-[#ffffff] space-y-4">
                {/* AI Message */}
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#2e44a7]/20 flex items-center justify-center mt-1">
                    <span className="material-symbols-outlined text-[#0f2a90] text-sm">psychology</span>
                  </div>
                  <div className="bg-[#eff4ff] p-4 rounded-2xl rounded-tl-sm border border-[#c5c5d4]/30 text-[#0b1c30]">
                    <p className="mb-3 font-body-md text-sm">{tutorData.feedback}</p>

                    {tutorData.reference && (
                      <div className="bg-white p-3 rounded-lg border-l-4 border-[#6e4400] text-xs">
                        <span className="font-label-caps text-[#6e4400] block mb-1">{tutorData.reference}</span>
                        {tutorData.formula && (
                          <p className="text-[#454652] font-mono font-bold text-xs">{tutorData.formula}</p>
                        )}
                      </div>
                    )}

                    <p className="mt-3 font-body-md text-xs leading-relaxed text-[#454652]">
                      {tutorData.explanation}
                    </p>
                  </div>
                </div>

                {/* Quick Prompts */}
                <div className="flex flex-col gap-2 pl-11">
                  <button
                    onClick={() => handleAskTutor("Explain it simpler")}
                    disabled={loadingAI}
                    className="text-left py-2 px-4 rounded-xl border border-[#c5c5d4]/50 hover:bg-[#e5eeff] transition-colors text-xs text-[#0f2a90] flex items-center justify-between group cursor-pointer"
                  >
                    <span>Explain it simpler</span>
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
                  </button>
                  <button
                    onClick={() => handleAskTutor("Show me a visual example")}
                    disabled={loadingAI}
                    className="text-left py-2 px-4 rounded-xl border border-[#c5c5d4]/50 hover:bg-[#e5eeff] transition-colors text-xs text-[#0f2a90] flex items-center justify-between group cursor-pointer"
                  >
                    <span>Show me a visual example</span>
                    <span className="material-symbols-outlined text-sm">image</span>
                  </button>
                </div>

                {/* Ask Custom Question Input */}
                <div className="pl-11 pt-2 flex gap-2">
                  <input
                    type="text"
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    placeholder="Ask AI Tutor anything..."
                    className="flex-1 text-xs px-3 py-2 border border-[#c5c5d4] rounded-lg focus:outline-none focus:border-[#0f2a90]"
                  />
                  <button
                    onClick={() => customPrompt.trim() && handleAskTutor(customPrompt)}
                    className="bg-[#0f2a90] text-white px-3 py-2 rounded-lg text-xs font-label-caps hover:bg-[#2e44a7] cursor-pointer"
                  >
                    Send
                  </button>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-4 bg-white border-t border-[#c5c5d4]/30 flex gap-3">
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setShowTutor(false);
                  }}
                  className="flex-1 bg-[#e5eeff] text-[#0b1c30] py-2 rounded-full font-label-caps text-xs hover:bg-[#dce9ff] transition-colors text-center border border-[#c5c5d4]/30 cursor-pointer"
                >
                  Retry Question
                </button>
                <button
                  onClick={onBackToPath}
                  className="flex-1 bg-[#0f2a90] text-white py-2 rounded-full font-label-caps text-xs shadow-sm hover:bg-[#0f2a90]/90 transition-all text-center cursor-pointer"
                >
                  Next Question
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

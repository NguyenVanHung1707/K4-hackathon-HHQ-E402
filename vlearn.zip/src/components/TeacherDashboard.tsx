import React, { useState } from 'react';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
} from 'chart.js';
import { Radar, Line } from 'react-chartjs-2';
import { StudentPerformance } from '../types';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale
);

interface TeacherDashboardProps {
  onNavigateToUpload: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onNavigateToUpload }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const initialStudents: StudentPerformance[] = [
    { id: '1', name: 'Nguyen Van A', mssv: 'SV2024001', grade: 92, status: 'On Track', avatarInitials: 'NA' },
    { id: '2', name: 'Tran Thi B', mssv: 'SV2024045', grade: 54, status: 'At Risk', avatarInitials: 'TB' },
    { id: '3', name: 'Le Van C', mssv: 'SV2024089', grade: 76, status: 'Needs Review', avatarInitials: 'LC' },
    { id: '4', name: 'Pham Minh D', mssv: 'SV2024099', grade: 88, status: 'On Track', avatarInitials: 'PD' },
  ];

  const filteredStudents = initialStudents.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.mssv.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Radar Chart Data
  const radarData = {
    labels: ['Syntax', 'Logic', 'Algorithms', 'Data Structs', 'Debugging', 'Optimization'],
    datasets: [
      {
        label: 'Class Average',
        data: [85, 65, 70, 60, 55, 45],
        backgroundColor: 'rgba(46, 68, 167, 0.2)',
        borderColor: '#0f2a90',
        pointBackgroundColor: '#0f2a90',
        borderWidth: 2,
      },
      {
        label: 'Target Benchmark',
        data: [80, 80, 80, 80, 80, 80],
        backgroundColor: 'transparent',
        borderColor: '#c5c5d4',
        borderDash: [5, 5],
        pointRadius: 0,
        borderWidth: 2,
      },
    ],
  };

  const radarOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      r: {
        angleLines: { color: '#e5eeff' },
        grid: { color: '#e5eeff' },
        ticks: { display: false, min: 0, max: 100 },
        pointLabels: { font: { family: "'Inter', sans-serif", size: 11 }, color: '#454652' },
      },
    },
    plugins: {
      legend: { position: 'bottom' as const, labels: { usePointStyle: true, boxWidth: 8 } },
    },
  };

  // Line Chart Data
  const lineData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
    datasets: [
      {
        label: 'Completion Rate (%)',
        data: [40, 55, 68, 75, 82, 82],
        borderColor: '#006c49',
        backgroundColor: 'rgba(0, 108, 73, 0.1)',
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: '#ffffff',
        pointBorderColor: '#006c49',
        pointBorderWidth: 2,
        pointRadius: 4,
      },
    ],
  };

  const lineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        grid: { color: '#eff4ff' },
        ticks: { color: '#757684' },
      },
      x: {
        grid: { display: false },
        ticks: { color: '#757684' },
      },
    },
    plugins: {
      legend: { display: false },
    },
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] font-body-md min-h-screen flex flex-col">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-[#e5eeff] px-4 md:px-10 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAUvfo_dixjB29xDYG90IjH5Rl4GTSUJROotHNVCgfroFZk3j51WmuGyNhAi5IcESOcAhB7JD6b0n4ha2QV-N7SzyqozWcgyF67TCQ08T_tqby0mDi55r_LvYw2xoBvzseatmKFDA9DOvayOtS09MZalWyak2_wRATwbKbUBz7zfAN3NnY5p8Omu6IMsZGQciLuDOv77Qrq9686fG4TFyL3gx4t1mh6JEIzyT762-eKESLvsJzJS-RNRQ"
            alt="VLearn Logo"
            className="h-8 w-auto"
          />
          <span className="font-display-lg text-xl font-bold text-[#0f2a90]">VLearn</span>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">notifications</span>
          </button>
          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">help</span>
          </button>
          <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-[#0f2a90]">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBdPUzok27aQrZzD9cUT79VYBiV1FvcOzaI9simfegmlrEILaXK6CPFpFvwV9ZoE2l7ndLRn4f-ZF8Cd7hUAymw-fPBFmcf3v8gZWbEsrBYwKIqtJ_rsYUIg8ZxrV1Gn8C41o49gLKWhg9phmYO5gMWfLDyMZrcFT63I4lWapRSINTKCwdVrCz9MA8F13GOH5iWpsQ5LotDUFiN5MatzQmnQDFT3MiEe6MeTpV28SZJLzAXNBq4LPLeog"
              alt="Teacher avatar"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="hidden md:flex flex-col w-[260px] bg-white border-r border-[#c5c5d4] p-4 gap-2">
          <div className="px-4 py-3 mb-2 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#2e44a7] flex items-center justify-center text-white overflow-hidden">
              <span className="material-symbols-outlined text-xl">school</span>
            </div>
            <div>
              <h2 className="font-headline-md text-sm font-semibold text-[#0b1c30]">Instructor Portal</h2>
              <p className="font-label-caps text-[10px] text-[#757684]">Academic Rigor</p>
            </div>
          </div>

          <a href="#" className="flex items-center gap-3 px-4 py-3 bg-[#2e44a7] text-white rounded-xl font-semibold text-sm">
            <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>
              dashboard
            </span>
            <span>Dashboard</span>
          </a>

          <button
            onClick={onNavigateToUpload}
            className="flex items-center gap-3 px-4 py-3 text-[#454652] hover:bg-[#eff4ff] hover:text-[#0f2a90] rounded-xl text-sm font-medium transition-all text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">cloud_upload</span>
            <span>Upload Content</span>
          </button>

          <div className="mt-4 px-2">
            <button
              onClick={onNavigateToUpload}
              className="w-full py-3 px-4 bg-[#0f2a90] text-white font-headline-md text-xs font-semibold rounded-xl hover:bg-[#2e44a7] transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <span className="material-symbols-outlined text-base">add</span>
              Create New Module
            </button>
          </div>

          <div className="mt-auto border-t border-[#c5c5d4]/50 pt-4 space-y-1">
            <a href="#" className="flex items-center gap-3 px-4 py-2 text-[#454652] hover:bg-[#eff4ff] rounded-xl text-sm">
              <span className="material-symbols-outlined text-base">settings</span>
              <span>Settings</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-4 py-2 text-[#454652] hover:bg-[#eff4ff] rounded-xl text-sm">
              <span className="material-symbols-outlined text-base">contact_support</span>
              <span>Support</span>
            </a>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 md:p-10 max-w-[1280px] mx-auto w-full">
          {/* Header Title */}
          <div className="flex justify-between items-end mb-8">
            <div>
              <h1 className="font-display-lg text-3xl md:text-4xl font-bold text-[#0b1c30] mb-2">
                Class Overview
              </h1>
              <p className="font-body-lg text-[#454652] text-sm md:text-base">
                CS101: Introduction to Computer Science (Fall 2024)
              </p>
            </div>
            <span className="px-3 py-1 bg-[#d3e4fe] text-[#454652] font-label-caps text-xs rounded-full flex items-center gap-1">
              <span className="material-symbols-outlined text-xs">calendar_today</span>
              THIS WEEK
            </span>
          </div>

          {/* KPIs Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* KPI 1 */}
            <div className="bg-white border border-[#c5c5d4] rounded-xl p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start mb-4">
                <span className="font-label-caps text-xs text-[#454652]">TỔNG SỐ SINH VIÊN</span>
                <span className="material-symbols-outlined text-[#0f2a90] bg-[#2e44a7]/20 p-1.5 rounded-md text-lg">
                  groups
                </span>
              </div>
              <div>
                <span className="font-display-lg text-4xl text-[#0b1c30] block font-bold">124</span>
                <div className="flex items-center gap-1 mt-2 text-[#006c49] text-xs font-semibold">
                  <span className="material-symbols-outlined text-xs">trending_up</span>
                  <span>+2% from last term</span>
                </div>
              </div>
            </div>

            {/* KPI 2 */}
            <div className="bg-white border border-[#c5c5d4] rounded-xl p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start mb-4">
                <span className="font-label-caps text-xs text-[#454652]">TỶ LỆ HOÀN THÀNH</span>
                <span className="material-symbols-outlined text-[#006c49] bg-[#6cf8bb]/30 p-1.5 rounded-md text-lg">
                  task_alt
                </span>
              </div>
              <div>
                <span className="font-display-lg text-4xl text-[#0b1c30] block font-bold">82%</span>
                <div className="w-full bg-[#d3e4fe] h-1.5 mt-3 rounded-full overflow-hidden">
                  <div className="bg-[#006c49] h-full" style={{ width: '82%' }} />
                </div>
              </div>
            </div>

            {/* KPI 3 */}
            <div className="bg-white border border-[#c5c5d4] rounded-xl p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start mb-4">
                <span className="font-label-caps text-xs text-[#454652]">ĐIỂM TRUNG BÌNH</span>
                <span className="material-symbols-outlined text-[#6e4400] bg-[#ffddb8] p-1.5 rounded-md text-lg">
                  grade
                </span>
              </div>
              <div>
                <span className="font-display-lg text-4xl text-[#0b1c30] block font-bold">B+</span>
                <span className="text-xs text-[#757684] mt-2 block">Median Score: 85/100</span>
              </div>
            </div>

            {/* KPI 4 */}
            <div className="bg-white border-1 border-[#c5c5d4] border-l-4 border-l-[#ba1a1a] rounded-xl p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start mb-4">
                <span className="font-label-caps text-xs text-[#454652]">CÂU HỎI KHÓ NHẤT</span>
                <span className="material-symbols-outlined text-[#ba1a1a] bg-[#ffdad6] p-1.5 rounded-md text-lg">
                  warning
                </span>
              </div>
              <div>
                <span className="font-headline-md text-lg text-[#0b1c30] block font-bold mb-1">
                  Q4: Recursion Logic
                </span>
                <span className="text-xs text-[#ba1a1a] font-semibold flex items-center gap-1">
                  <span className="material-symbols-outlined text-xs">arrow_downward</span>
                  45% fail rate
                </span>
              </div>
            </div>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Radar Chart */}
            <div className="bg-white border border-[#c5c5d4] rounded-xl p-6 lg:col-span-1 flex flex-col">
              <h3 className="font-student-card-title text-base font-bold text-[#0b1c30] mb-4">
                Lỗ hổng kiến thức
              </h3>
              <div className="flex-1 relative w-full h-[260px] flex items-center justify-center">
                <Radar data={radarData} options={radarOptions} />
              </div>
            </div>

            {/* Line Chart */}
            <div className="bg-white border border-[#c5c5d4] rounded-xl p-6 lg:col-span-2 flex flex-col">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-student-card-title text-base font-bold text-[#0b1c30]">
                  Tiến độ lớp học
                </h3>
                <button className="text-[#0f2a90] text-xs font-semibold flex items-center gap-1 hover:underline cursor-pointer">
                  View Full Report
                  <span className="material-symbols-outlined text-sm">chevron_right</span>
                </button>
              </div>
              <div className="flex-1 relative w-full h-[260px]">
                <Line data={lineData} options={lineOptions} />
              </div>
            </div>
          </div>

          {/* Student Table */}
          <div className="bg-white border border-[#c5c5d4] rounded-xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-[#c5c5d4] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <h3 className="font-student-card-title text-base font-bold text-[#0b1c30]">
                Sinh viên cần chú ý
              </h3>
              <div className="relative w-full sm:w-64">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#757684] text-sm">
                  search
                </span>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search student..."
                  className="w-full pl-9 pr-4 py-2 border-2 border-[#c5c5d4] rounded-xl text-xs focus:border-[#0f2a90] outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#eff4ff] text-xs font-label-caps text-[#454652] border-b border-[#c5c5d4]">
                    <th className="py-4 px-6 font-semibold">TÊN SINH VIÊN</th>
                    <th className="py-4 px-6 font-semibold">MSSV</th>
                    <th className="py-4 px-6 font-semibold">ĐIỂM HIỆN TẠI</th>
                    <th className="py-4 px-6 font-semibold">TRẠNG THÁI</th>
                    <th className="py-4 px-6 font-semibold text-right">ACTION</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-[#0b1c30]">
                  {filteredStudents.map((st) => {
                    let badgeClass = "bg-[#d3e4fe] text-[#454652]";
                    if (st.status === 'On Track') badgeClass = "bg-[#6cf8bb]/40 text-[#00714d]";
                    if (st.status === 'At Risk') badgeClass = "bg-[#ffdad6] text-[#93000a]";

                    return (
                      <tr key={st.id} className="border-b border-[#c5c5d4]/50 hover:bg-[#f8f9ff] transition-colors">
                        <td className="py-4 px-6 font-semibold flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-[#2e44a7] text-white flex items-center justify-center font-bold text-xs">
                            {st.avatarInitials}
                          </div>
                          {st.name}
                        </td>
                        <td className="py-4 px-6 text-[#757684] text-xs font-mono">{st.mssv}</td>
                        <td className="py-4 px-6 font-bold">{st.grade}</td>
                        <td className="py-4 px-6">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${badgeClass}`}>
                            <span className="w-1.5 h-1.5 rounded-full bg-current" />
                            {st.status}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-right">
                          <button className="text-[#757684] hover:text-[#0f2a90] cursor-pointer">
                            <span className="material-symbols-outlined">more_vert</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

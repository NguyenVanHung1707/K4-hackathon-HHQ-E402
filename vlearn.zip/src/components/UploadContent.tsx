import React, { useState } from 'react';
import { Question } from '../types';

interface UploadContentProps {
  onBackToDashboard: () => void;
  onSaveModule: () => void;
}

export const UploadContent: React.FC<UploadContentProps> = ({ onBackToDashboard, onSaveModule }) => {
  const [selectedFile, setSelectedFile] = useState<string>('Chapter4_Photosynthesis.pdf');
  const [targetSession, setTargetSession] = useState<string>('Week 4: Cellular Respiration');
  const [questionFormat, setQuestionFormat] = useState<string>('Multiple Choice (Trắc nghiệm)');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Easy');

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: 1,
      type: 'multiple-choice',
      question: 'What is the primary function of chlorophyll in the process of photosynthesis?',
      options: [
        { id: 'a', label: 'Option A', text: 'To absorb light energy from the sun.' },
        { id: 'b', label: 'Option B', text: 'To convert glucose into ATP.' },
        { id: 'c', label: 'Option C', text: 'To absorb water from the soil.' },
      ],
      correctAnswer: 'a',
    },
    {
      id: 2,
      type: 'fill-in-blanks',
      question: 'During the light-dependent reactions, oxygen is released as a byproduct of the splitting of water molecules.',
      acceptableAnswers: ['water', 'H2O'],
      correctAnswer: 'water',
    },
  ]);

  const [notification, setNotification] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0].name);
    }
  };

  const handleGenerateAIQuiz = async () => {
    setIsGenerating(true);
    setNotification('AI đang phân tích tài liệu và khởi tạo bộ câu hỏi...');

    try {
      const response = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceText: `Chapter4 Photosynthesis file ${selectedFile}`,
          session: targetSession,
          format: questionFormat,
          difficulty: difficulty,
        }),
      });

      const data = await response.json();
      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
      }
    } catch {
      // Fallback stays
    } finally {
      setIsGenerating(false);
      setNotification('Đã tạo thành công bộ câu hỏi AI mới!');
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const handleDeleteQuestion = (id: number) => {
    setQuestions(questions.filter((q) => q.id !== id));
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] min-h-screen font-body-md">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-[#e5eeff] px-4 md:px-10 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onBackToDashboard}
            className="flex items-center gap-2 text-[#454652] hover:text-[#0f2a90] text-xs font-label-caps cursor-pointer"
          >
            <span className="material-symbols-outlined text-sm">arrow_back</span>
            Back to Dashboard
          </button>
          <span className="font-display-lg text-xl font-bold text-[#0f2a90]">VLearn</span>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">notifications</span>
          </button>
          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">help</span>
          </button>
          <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-[#0f2a90]">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDoD77SS1BL10sgkNNwwzKVIxilJn5RHaLdrNLUXFhwlcckHLQVvtFmitO_FQWEpxvbuywsM0-3deoTEH_geMU6M__xEorpNa7CSyRjGx40ug3XksgfGhQxLtbi7ELQ0Agqm5gL7bcMYKDvKO3bR5hWdg_-zjc7mNIRUpBGfE4Gab3g9hU1tokCNZ_03mb1CUbXhWvoTV-X5eooybSNQ02LeqJOtLYehhtz6UJHrImXCiojfactUaXEEQ"
              alt="Teacher avatar"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="p-6 md:p-10 max-w-[1280px] mx-auto">
        {notification && (
          <div className="mb-6 bg-[#6cf8bb]/30 border border-[#006c49] text-[#00714d] px-4 py-3 rounded-xl text-sm font-semibold flex items-center justify-between">
            <span>{notification}</span>
            <span className="material-symbols-outlined text-sm cursor-pointer" onClick={() => setNotification(null)}>
              close
            </span>
          </div>
        )}

        <div className="mb-8">
          <h1 className="font-headline-md text-2xl md:text-3xl font-bold text-[#0b1c30]">
            Knowledge Generation
          </h1>
          <p className="font-body-md text-sm text-[#454652] mt-1">
            Upload curriculum materials to automatically generate structured assessments.
          </p>
        </div>

        {/* 12-Column Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          {/* Left Column (5 Cols) */}
          <div className="xl:col-span-5 flex flex-col gap-6">
            {/* Upload Zone */}
            <div className="bg-white border border-[#c5c5d4] rounded-2xl p-6 relative overflow-hidden shadow-sm">
              <label className="font-label-caps text-xs text-[#454652] uppercase block mb-4">
                SOURCE MATERIAL
              </label>

              <div className="border-2 border-dashed border-[#c5c5d4] rounded-xl p-8 flex flex-col items-center justify-center text-center bg-[#eff4ff] hover:bg-[#e5eeff] transition-all relative">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  accept=".pdf,.docx,.mp3"
                />
                <div className="h-16 w-16 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm border border-[#c5c5d4]">
                  <span className="material-symbols-outlined text-3xl text-[#0f2a90]">upload_file</span>
                </div>
                <h3 className="font-body-md font-semibold text-[#0b1c30] mb-1">
                  Drag & Drop Files Here
                </h3>
                <p className="font-body-md text-xs text-[#454652] mb-6">
                  Supports PDF, DOCX, MP3 (Max 50MB)
                </p>
                <button type="button" className="border border-[#c5c5d4] text-[#454652] font-body-md text-xs font-medium rounded-xl px-5 py-2 hover:bg-white bg-white shadow-sm pointer-events-none">
                  Browse Files
                </button>
              </div>

              {/* Uploaded File */}
              {selectedFile && (
                <div className="mt-4 flex items-center justify-between p-3 border border-[#c5c5d4] rounded-lg bg-[#f8f9ff]">
                  <div className="flex items-center gap-3">
                    <span className="material-symbols-outlined text-[#2e44a7]">picture_as_pdf</span>
                    <div>
                      <p className="font-body-md text-xs font-medium text-[#0b1c30]">{selectedFile}</p>
                      <p className="font-body-md text-[11px] text-[#757684]">2.4 MB • Complete</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedFile('')}
                    className="text-[#757684] hover:text-[#ba1a1a] transition-colors cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-base">close</span>
                  </button>
                </div>
              )}
            </div>

            {/* Quiz Settings */}
            <div className="bg-white border border-[#c5c5d4] rounded-2xl p-6 shadow-sm">
              <label className="font-label-caps text-xs text-[#454652] uppercase block mb-6">
                GENERATION PARAMETERS
              </label>

              <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="font-label-caps text-[11px] text-[#757684] block mb-1">
                    Target Session (Buổi học)
                  </label>
                  <select
                    value={targetSession}
                    onChange={(e) => setTargetSession(e.target.value)}
                    className="w-full bg-[#f8f9ff] border border-[#c5c5d4] rounded-lg p-3 font-body-md text-xs text-[#0b1c30] outline-none focus:border-[#0f2a90]"
                  >
                    <option>Week 4: Cellular Respiration</option>
                    <option>Week 5: Genetics</option>
                  </select>
                </div>

                <div>
                  <label className="font-label-caps text-[11px] text-[#757684] block mb-1">
                    Question Format (Dạng câu hỏi)
                  </label>
                  <select
                    value={questionFormat}
                    onChange={(e) => setQuestionFormat(e.target.value)}
                    className="w-full bg-[#f8f9ff] border border-[#c5c5d4] rounded-lg p-3 font-body-md text-xs text-[#0b1c30] outline-none focus:border-[#0f2a90]"
                  >
                    <option>Multiple Choice (Trắc nghiệm)</option>
                    <option>Fill in the Blanks (Điền khuyết)</option>
                  </select>
                </div>

                <div>
                  <label className="font-label-caps text-[11px] text-[#757684] block mb-1">
                    Difficulty Level (Độ khó)
                  </label>
                  <div className="flex gap-2 mt-2">
                    {(['Easy', 'Medium', 'Hard'] as const).map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setDifficulty(lvl)}
                        className={`flex-1 py-2 border rounded-lg text-xs font-medium transition-all cursor-pointer ${
                          difficulty === lvl
                            ? 'bg-[#2e44a7] text-white border-[#0f2a90]'
                            : 'border-[#c5c5d4] text-[#454652] hover:bg-[#eff4ff]'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-[#c5c5d4] border-dashed">
                  <button
                    type="button"
                    onClick={handleGenerateAIQuiz}
                    disabled={isGenerating}
                    className="w-full bg-[#0f2a90] text-white font-headline-md text-sm font-semibold py-3 rounded-xl hover:bg-[#2e44a7] shadow-sm transition-all flex justify-center items-center gap-2 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-lg">auto_awesome</span>
                    {isGenerating ? 'AI Generating...' : 'Generate AI Quiz'}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Column (7 Cols) */}
          <div className="xl:col-span-7 flex flex-col gap-6">
            {/* AI Engine Processing Bar */}
            <div className="bg-white border border-[#c5c5d4] rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-headline-md text-base text-[#0b1c30] flex items-center gap-2 font-semibold">
                  <span className={`material-symbols-outlined text-[#0f2a90] ${isGenerating ? 'animate-spin' : ''}`}>
                    sync
                  </span>
                  AI Engine Processing
                </h2>
                <span className="font-label-caps text-xs text-[#006c49] font-bold bg-[#6cf8bb]/40 px-3 py-1 rounded-full">
                  75% Complete
                </span>
              </div>

              {/* Progress Momentum Bar */}
              <div className="h-3 w-full bg-[#e5eeff] rounded-full overflow-hidden shadow-inner mb-3">
                <div className="h-full bg-gradient-to-r from-[#0f2a90] to-[#006c49] rounded-full momentum-bar-inner" />
              </div>

              <div className="flex justify-between font-label-caps text-[10px] sm:text-xs text-[#454652]">
                <span className="text-[#0f2a90] font-bold">1. TRÍCH XUẤT VĂN BẢN</span>
                <span className="text-[#0f2a90] font-bold">2. LỌC NHIỄU</span>
                <span className="text-[#0b1c30]">3. AI ĐANG SINH CÂU HỎI</span>
              </div>
            </div>

            {/* Generated Questions Draft Preview */}
            <div className="flex-1 bg-[#eff4ff] rounded-2xl p-4 md:p-6 border border-[#c5c5d4]/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-body-md font-semibold text-[#0b1c30]">Generated Questions Draft</h3>
                <span className="font-label-caps text-xs bg-white border border-[#c5c5d4] px-2.5 py-1 rounded-md text-[#454652]">
                  {questions.length} Drafts
                </span>
              </div>

              <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                {questions.map((q, idx) => (
                  <div key={q.id} className="bg-white border border-[#c5c5d4] rounded-2xl p-5 shadow-sm">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#2e44a7] text-white flex items-center justify-center font-label-caps text-xs font-bold">
                          {idx + 1}
                        </span>
                        <span className="font-label-caps text-[10px] bg-[#dce9ff] px-2 py-0.5 rounded text-[#454652]">
                          {q.type === 'multiple-choice' ? 'Multiple Choice' : 'Fill in Blanks'}
                        </span>
                      </div>
                      <button
                        onClick={() => handleDeleteQuestion(q.id)}
                        className="text-[#757684] hover:text-[#ba1a1a] p-1 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm">delete</span>
                      </button>
                    </div>

                    <p className="font-body-md text-sm text-[#0b1c30] font-medium mb-4">
                      {q.question}
                    </p>

                    {q.type === 'multiple-choice' && q.options && (
                      <div className="space-y-2 pl-2">
                        {q.options.map((opt) => (
                          <div
                            key={opt.id}
                            className={`flex items-center gap-3 p-2.5 rounded-lg border text-xs ${
                              opt.id === q.correctAnswer
                                ? 'border-[#0f2a90] bg-[#2e44a7]/10 font-semibold'
                                : 'border-transparent bg-[#f8f9ff]'
                            }`}
                          >
                            <span className="material-symbols-outlined text-sm text-[#0f2a90]">
                              {opt.id === q.correctAnswer ? 'check_circle' : 'radio_button_unchecked'}
                            </span>
                            <span>{opt.text}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {q.type === 'fill-in-blanks' && (
                      <div className="bg-[#f8f9ff] p-3 rounded-lg border border-[#c5c5d4] text-xs">
                        <span className="text-[#757684] font-label-caps uppercase mr-2">ACCEPTABLE ANSWERS:</span>
                        {q.acceptableAnswers?.map((ans, i) => (
                          <span key={i} className="bg-[#e5eeff] px-2 py-1 rounded text-[#0b1c30] mr-2 font-mono font-bold">
                            {ans}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Save Actions */}
              <div className="pt-6 flex justify-end gap-3">
                <button
                  onClick={onBackToDashboard}
                  className="border border-[#c5c5d4] text-[#0b1c30] bg-white font-body-md font-medium px-6 py-2.5 rounded-xl hover:bg-[#f8f9ff] transition-colors text-xs cursor-pointer"
                >
                  Discard
                </button>
                <button
                  onClick={onSaveModule}
                  className="bg-[#006c49] text-white font-headline-md text-xs font-semibold px-8 py-2.5 rounded-xl hover:bg-[#006c49]/90 shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base">save</span>
                  Save to Module
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

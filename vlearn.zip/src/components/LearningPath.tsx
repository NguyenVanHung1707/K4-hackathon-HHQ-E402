import React from 'react';
import { StudentProfile } from '../types';

interface LearningPathProps {
  studentProfile: StudentProfile;
  onStartQuiz: (lessonTitle?: string) => void;
}

export const LearningPath: React.FC<LearningPathProps> = ({ studentProfile, onStartQuiz }) => {
  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] min-h-screen font-body-md flex flex-col">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-[#e5eeff] px-4 md:px-10 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="font-display-lg text-2xl font-bold text-[#0f2a90]">VLearn</span>
        </div>

        <div className="flex items-center gap-4">
          {/* XP & Streak Bar */}
          <div className="bg-white border border-[#c5c5d4] rounded-full px-4 py-1.5 flex items-center gap-4 shadow-sm text-xs font-label-caps">
            <div className="flex items-center gap-1.5 text-[#006c49]">
              <span className="material-symbols-outlined text-sm text-[#006c49]">grade</span>
              <span>XP: 1,250</span>
            </div>
            <div className="h-3 w-px bg-[#c5c5d4]" />
            <div className="flex items-center gap-1.5 text-[#6e4400]">
              <span className="material-symbols-outlined text-sm text-[#ffae3c]" style={{ fontVariationSettings: "'FILL' 1" }}>
                local_fire_department
              </span>
              <span>5 DAY STREAK</span>
            </div>
          </div>

          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">notifications</span>
          </button>
          <button className="p-2 text-[#454652] hover:text-[#0f2a90] rounded-full hover:bg-[#eff4ff]">
            <span className="material-symbols-outlined">help</span>
          </button>
          <div className="w-8 h-8 rounded-full bg-[#2e44a7] text-white font-bold flex items-center justify-center text-xs overflow-hidden border border-[#0f2a90]">
            {studentProfile.fullName.charAt(0) || 'S'}
          </div>
        </div>
      </header>

      {/* Main Path Canvas */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-10 flex flex-col items-center">
        <div className="text-center mb-12">
          <h1 className="font-display-lg text-4xl md:text-5xl font-bold text-[#0f2a90] mb-3">
            My Learning Path
          </h1>
          <p className="font-body-lg text-[#454652] max-w-lg mx-auto">
            Continue your journey through the Mathematics curriculum. You're doing great, {studentProfile.fullName.split(' ')[0]}!
          </p>
        </div>

        {/* Path Map */}
        <div className="w-full max-w-md relative flex flex-col items-center gap-16 py-8">
          {/* Node 1: Completed */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-[#006c49] text-white flex items-center justify-center shadow-md">
              <span className="material-symbols-outlined text-3xl font-bold">check</span>
            </div>
            <span className="mt-2 font-label-caps text-xs text-[#006c49]">Buổi 1: Basic Operations</span>
          </div>

          {/* Node 2: Current Active Lesson */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="flex items-center gap-6">
              {/* Animated Play Ring */}
              <div className="w-20 h-20 rounded-full border-4 border-[#2e44a7] bg-[#0f2a90] text-white flex items-center justify-center shadow-lg relative animate-pulse">
                <span className="material-symbols-outlined text-4xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                  play_arrow
                </span>
              </div>

              {/* Lesson Card */}
              <div className="bg-white border-2 border-[#0f2a90] rounded-2xl p-5 shadow-md w-64 text-left">
                <p className="font-headline-md text-base font-semibold text-[#0f2a90] mb-1">
                  Buổi 2: Algebra & Equations
                </p>
                <p className="font-body-md text-xs text-[#454652] mb-4">
                  Current Lesson
                </p>
                <button
                  onClick={() => onStartQuiz("Buổi 2: Algebra & Equations")}
                  className="w-full bg-[#0f2a90] text-white py-2.5 rounded-full font-label-caps text-xs hover:bg-[#2e44a7] transition-all flex items-center justify-center gap-2 shadow cursor-pointer"
                >
                  Start Quiz
                </button>
              </div>
            </div>
          </div>

          {/* Node 3: Locked */}
          <div className="relative z-10 flex flex-col items-center opacity-60">
            <div className="w-16 h-16 rounded-full bg-[#e5eeff] text-[#757684] flex items-center justify-center shadow-inner border border-[#c5c5d4]">
              <span className="material-symbols-outlined text-2xl">lock</span>
            </div>
            <span className="mt-2 font-label-caps text-xs text-[#757684]">Buổi 3: Quadratic Functions</span>
          </div>

          {/* Node 4: Locked */}
          <div className="relative z-10 flex flex-col items-center opacity-40">
            <div className="w-16 h-16 rounded-full bg-[#e5eeff] text-[#757684] flex items-center justify-center shadow-inner border border-[#c5c5d4]">
              <span className="material-symbols-outlined text-2xl">lock</span>
            </div>
            <span className="mt-2 font-label-caps text-xs text-[#757684]">Buổi 4: Physics & Classical Mechanics</span>
          </div>
        </div>
      </main>
    </div>
  );
};
